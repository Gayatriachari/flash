package in.ineuron.controller;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Module {
  private String name;
  private String password;
  private String contact;
  private String email; 
  private String repassword;
  int inValue=-1;
  int rowcount=0;
  int count=0;
  //sql objects 
  static Connection connection=null; 
  static Statement statement=null; 
  static ResultSet resultSet=null;
  
  
  //jdbc logins 
  String url="jdbc:mysql:///buying_selling";
  String user="root"; 
  String password1="Achari@2001";
  
  //****************************//
  public void setName(String name) {
	  this.name=name;
  }
  public void setPwd(String password) {
	  this.password=password;
  }
  public void setNum(String contact) {
	  this.contact=contact;
  }
  public void setEmail(String email) {
	  this.email=email;
  } 
  public void setRepwd(String repassword) {
	  this.repassword=repassword;
  }
  public String getName() {
	  return name;
  }
  public String getPwd() {
	  return password;
  }
  public String getNum() {
	  return contact;
  }
  public String getEmail() {
	  return email;
  }
  public String getRepwd() {
	  return repassword;
  }
  
  public void display()  {
        System.out.println("in display method");
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("in display method");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			connection=DriverManager.getConnection(url, user, password1);
			if(connection!=null) {
				statement=connection.createStatement();
				if(statement!=null) { 
					if(name==null) {
						String sqlSelectQuery="select email, password from userdata";
						resultSet=statement.executeQuery(sqlSelectQuery);
						System.out.println("at query");
						if(resultSet!=null) { 
							while(resultSet.next()) {
								System.out.println("inside whileloop");
								String email1=resultSet.getString(1); 
								String pwd1=resultSet.getString(2); 
								if(email.equalsIgnoreCase(email1) && password.equalsIgnoreCase(pwd1)) { 
									System.out.println("inside if");
									inValue=1;
								}
							}
						}
					}else { 
						
						String sqlQuery="select email from userdata"; 
						resultSet=statement.executeQuery(sqlQuery);
						while(resultSet.next()) { 
							String e=resultSet.getString(1);
							if(email.equals(e)) { count=count+1;}	
							System.out.println(e);
						}	
						System.out.println(count);
						if(count==0) { 
							System.out.println(email);
							System.out.println(contact);
							String query = "insert into userdata(email, contact, password, name, repassword) values('"+email+"', '"+contact+"', '"+password+"', '"+name+"', '"+repassword+"')";

							if(password.equals(repassword)) {
								
								rowcount=statement.executeUpdate(query);
								
							}
						}
						
						
						
					}
				}
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			if(statement!=null)
				try {
					statement.close(); 
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			if(connection!=null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
 
 
  }
}
