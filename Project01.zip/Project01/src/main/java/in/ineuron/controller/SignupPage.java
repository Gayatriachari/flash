package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/signup")
public class SignupPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email=request.getParameter("email");
		String pwd=request.getParameter("pwd");
		String repwd=request.getParameter("repwd");
		String name=request.getParameter("name");
		String num=request.getParameter("num"); 
		Module obj=new Module(); 
		obj.setEmail(email); 
		obj.setPwd(pwd);
		obj.setName(name);
		obj.setRepwd(repwd);
		obj.setNum(num);
		obj.display(); 
		PrintWriter out=response.getWriter();
		if(obj.rowcount==1) {
			out.println("<h1 style='color:green; text-align:center'>REGISTRATION SUCCESS</h1>");
	    	out.println("<a style='text-align:center' href='./registration.html'>click on the link to go to home page</a>");
		}else if(obj.count>0) {
			out.println("<h1 style='color:red;text-align:center'>REGISTRACTION FAILED, ENTERED EMAIL IS ALREADY EXISTED</h1>");
	        out.println("<a style='text-align:center' href='./signin.html'>signin</a>");
		}
		else {
			out.println("<h1 style='color:red;text-align:center'>REGISTRACTION FAILED, PASSWORD MISMATCHED </h1>");
	        out.println("<a style='text-align:center' href='./signup.html'>register again</a><br><br>");
	        out.println("<a style='text-align:center' href='./signin.html'>signin</a>");
		}
	
	}

}
