package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/signin")
public class SigninPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
		String email=request.getParameter("email");
		String pwd=request.getParameter("pwd");
		Module obj=new Module(); 
		obj.setEmail(email); 
		obj.setPwd(pwd);
		System.out.println(obj.getEmail());
		System.out.println(obj.getPwd());
		obj.display();
		if(obj.inValue!=1) {  
			PrintWriter out=response.getWriter();
			out.println("<h1 style='color:red; text-align:center'>INVALID CREDENTIALS</h1>");
			 out.println("<a style='text-align:center' href='./signin.html'>signin</a><br><br>");	
			 out.println("<a style='text-align:center' href='./signup.html'>if u dont have account please signup</a><br><br>");
		}else {
			PrintWriter out=response.getWriter();		 
			out.println("<h1 style='color:green; text-align:center'>Login success</h1>"); 
			out.println("<a href='registration.html'>back to home page</a>");
			
		}
		

		
		
	}

}
